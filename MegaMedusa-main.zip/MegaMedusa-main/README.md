# MegaMedusa Machine Layer-7 DDoS Tool v3.2

## MegaMedusa V3.2 Main Display :
 ![Main](maindisplay.jpg)

### What is MegaMedusa?
- MegaMedusa is NodeJS DDoS Machine Layer-7 provided by RipperSec Team.

### News About MegaMedusa :
- https://www.radware.com/blog/security/2024/08/megamedusa-rippersec-public-web-ddos-attack-tool/
  
 ### Security that MegaMedusa can bypass :
- UAM Challenges Bypass ✅
- Cloudflare NoSec ✅
- DDoS Guard Bypass ✅
- vShield Website Bypass ✅
- ShieldSquare Captcha Bypass ✅
  
 ### Update v3.1 :
- Lagging Fixed & More Compatible.
- More power & bypasses.
- Ram & Cpu Usage (Low).
- Fixed Bugs.

 ### Update v3.2 :
- UAM Bypass Challenge Improvement.
- RPS Power Improvement.
- New Ui / Display.
- Auto Restart Attack If Ram Usage Reach 80%
- DDoS Maximum Hold: 100,000K Seconds.
- Device Stuck & Phone Overheating Fixed.
- Script Run More Smoothly Compared to Version 3.1
- VPS/RPD Suspend Problem Solved.

### Usage :
```
Usage: node MegaMedusa.js <link> <time> <rps> <threads> <proxy> 
Example: node MegaMedusa.js https://example.com 500 30 10 proxy.txt 
```

### Instructions :
- **Target**: By entering the victim's link target, you will be able to run a zombie botnet army to attack the victim
- **RPS**: Requests per second: A metric that measures the throughput of a system
- **Threads**: threads is a measure of bytes
- **Proxy**: While using proxy, you will attack in different ip & country and make traffic flooding

### Installation Command :
```
python3 nvminstaller.py
python3 installer.py
------------------------
After this commands installed. Restart your terminal.
```
### Note: Please make sure your NodeJS Version is V20 :
```
-> NodeJS Version Command Check :
nodejs -v
```

### Proxy Scrape Command :
```
python3 scrape.py
```
### OS Support :
- Debian.
- Ubuntu (Recommended).
- Kali Linux.
- Termux.
- Windows.

### Minimum Device Specifications :
- 2GB Ram.
- 2 Core.
- Internet Speed Minimum 30mbps.

## Refference :
<a href="https://t.me/RipperSec"><img title="Telegram" src="https://img.shields.io/badge/RipperSec-blue?style=for-the-badge&logo=telegram"></a>

## If you want to donate, click on the button :
<a href="https://sociabuzz.com/kudagila/donate"><img title="Donate" src="https://img.shields.io/badge/Donate-KudaGila-yellow?style=for-the-badge&logo=github"></a>
```
bc1q5z9kccxvwcx6dk9hsmezvhfg8yqjyj0hs3v52v (BTC)
```

## Disclaimer :
- This tool only for Education, Pentesting, and Research Purposes!
- MegaMedusa Power depends from your Device Specs. Don't blame this script not power if your phone sucks.
